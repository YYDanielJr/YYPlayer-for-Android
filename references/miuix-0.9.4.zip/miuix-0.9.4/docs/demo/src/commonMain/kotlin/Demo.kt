// Copyright 2025, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import top.yukonga.miuix.kmp.basic.ButtonDefaults
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.nav.core.NavDisplay
import top.yukonga.miuix.kmp.nav.core.NavKey
import top.yukonga.miuix.kmp.nav.core.navBackStackOf
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController

@Composable
fun Demo(demoId: String? = null) {
    val controller = remember { ThemeController(ColorSchemeMode.System) }
    MiuixTheme(controller = controller) {
        if (demoId == null) {
            DemoSelection()
        } else {
            availableComponents.first { it.id == demoId }.demo()
        }
    }
}

private data class AvailableComponent(val name: String, val id: String, val demo: @Composable () -> Unit)

private val availableComponents = listOf(
    AvailableComponent("Scaffold", "scaffold") { ScaffoldDemo() },
    AvailableComponent("Surface", "surface") { SurfaceDemo() },
    AvailableComponent("TopAppBar", "topAppBar") { TopAppBarDemo() },
    AvailableComponent("NavigationBar", "navigationBar") { NavigationBarDemo() },
    AvailableComponent("NavigationRail", "navigationRail") { NavigationRailDemo() },
    AvailableComponent("TabRow", "tabRow") { TabRowDemo() },
    AvailableComponent("BreadcrumbBar", "breadcrumbBar") { BreadcrumbBarDemo() },
    AvailableComponent("Card", "card") { CardDemo() },
    AvailableComponent("BasicComponent", "basicComponent") { BasicComponentDemo() },
    AvailableComponent("Button", "button") { ButtonDemo() },
    AvailableComponent("IconButton", "iconButton") { IconButtonDemo() },
    AvailableComponent("Text", "text") { TextDemo() },
    AvailableComponent("SmallTitle", "smallTitle") { SmallTitleDemo() },
    AvailableComponent("TextField", "textField") { TextFieldDemo() },
    AvailableComponent("Switch", "switch") { SwitchDemo() },
    AvailableComponent("Checkbox", "checkbox") { CheckboxDemo() },
    AvailableComponent("RadioButton", "radioButton") { RadioButtonDemo() },
    AvailableComponent("Slider", "slider") { SliderDemo() },
    AvailableComponent("NumberPicker", "numberPicker") { NumberPickerDemo() },
    AvailableComponent("ProgressIndicator", "progressIndicator") { ProgressIndicatorDemo() },
    AvailableComponent("Snackbar", "snackbar") { SnackbarDemo() },
    AvailableComponent("Tooltip", "tooltip") { TooltipDemo() },
    AvailableComponent("Badge", "badge") { BadgeDemo() },
    AvailableComponent("Icon", "icon") { IconDemo() },
    AvailableComponent("FloatingActionButton", "floatingActionButton") { FloatingActionButtonDemo() },
    AvailableComponent("FloatingToolbar", "floatingToolbar") { FloatingToolbarDemo() },
    AvailableComponent("Divider", "divider") { DividerDemo() },
    AvailableComponent("PullToRefresh", "pullToRefresh") { PullToRefreshDemo() },
    AvailableComponent("SearchBar", "searchBar") { SearchBarDemo() },
    AvailableComponent("ColorPicker", "colorPicker") { ColorPickerDemo() },
    AvailableComponent("ColorPalette", "colorPalette") { ColorPaletteDemo() },
    AvailableComponent("ArrowPreference", "arrowPreference") { ArrowPreferenceDemo() },
    AvailableComponent("SwitchPreference", "switchPreference") { SwitchPreferenceDemo() },
    AvailableComponent("CheckboxPreference", "checkboxPreference") { CheckboxPreferenceDemo() },
    AvailableComponent("RadioButtonPreference", "radioButtonPreference") { RadioButtonPreferenceDemo() },
    AvailableComponent("OverlayListPopup", "overlayListPopup") { OverlayListPopupDemo() },
    AvailableComponent("OverlayCascadingListPopup", "overlayCascadingListPopup") { OverlayCascadingListPopupDemo() },
    AvailableComponent("OverlayDropdownPreference", "overlayDropdownPreference") { OverlayDropdownPreferenceDemo() },
    AvailableComponent("OverlaySpinnerPreference", "overlaySpinnerPreference") { OverlaySpinnerPreferenceDemo() },
    AvailableComponent("OverlayDropdownMenu", "overlayDropdownMenu") { OverlayDropdownMenuDemo() },
    AvailableComponent("OverlayIconDropdownMenu", "overlayIconDropdownMenu") { OverlayIconDropdownMenuDemo() },
    AvailableComponent("OverlayIconCascadingDropdownMenu", "overlayIconCascadingDropdownMenu") { OverlayIconCascadingDropdownMenuDemo() },
    AvailableComponent("OverlayBottomSheet", "overlayBottomSheet") { OverlayBottomSheetDemo() },
    AvailableComponent("OverlayDialog", "overlayDialog") { OverlayDialogDemo() },
    AvailableComponent("WindowListPopup", "windowListPopup") { WindowListPopupDemo() },
    AvailableComponent("WindowCascadingListPopup", "windowCascadingListPopup") { WindowCascadingListPopupDemo() },
    AvailableComponent("WindowDropdownPreference", "windowDropdownPreference") { WindowDropdownPreferenceDemo() },
    AvailableComponent("WindowSpinnerPreference", "windowSpinnerPreference") { WindowSpinnerPreferenceDemo() },
    AvailableComponent("WindowDropdownMenu", "windowDropdownMenu") { WindowDropdownMenuDemo() },
    AvailableComponent("WindowIconDropdownMenu", "windowIconDropdownMenu") { WindowIconDropdownMenuDemo() },
    AvailableComponent("WindowIconCascadingDropdownMenu", "windowIconCascadingDropdownMenu") { WindowIconCascadingDropdownMenuDemo() },
    AvailableComponent("WindowBottomSheet", "windowBottomSheet") { WindowBottomSheetDemo() },
    AvailableComponent("WindowDialog", "windowDialog") { WindowDialogDemo() },
)

@Composable
private fun DemoSelection() {
    val backStack = remember { navBackStackOf(DemoScreen.Home) }

    NavDisplay(
        backStack = backStack,
    ) {
        entry<DemoScreen.Home> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(demoBackground()),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                        .widthIn(max = 600.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    availableComponents.forEach { demo ->
                        TextButton(
                            text = demo.name,
                            onClick = { backStack.add(DemoScreen.Component(demo.id)) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.textButtonColorsPrimary(),
                        )
                    }
                }
            }
        }
        entry<DemoScreen.Component> { screen ->
            Column {
                availableComponents.first { it.id == screen.id }.demo()
            }
        }
    }
}

private sealed interface DemoScreen : NavKey {
    data object Home : DemoScreen
    data class Component(val id: String) : DemoScreen
}
